class AuthorizeError(Exception):
    pass


class BadResponse(Exception):
    pass


class UnsupportedPlatform(Exception):
    pass


class UndefinedError(Exception):
    pass
